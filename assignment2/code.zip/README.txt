To run code:

Python 3

Main file is a jupyter notebook: main.ipynb
All modules run inside code is in : modules.py
