The main.ipynb : jupyter notebook with python 3 kernel
modules.py : python 3.

packages:
numpy
pandas
matplotlib

running the main.ipynb should run all code.
